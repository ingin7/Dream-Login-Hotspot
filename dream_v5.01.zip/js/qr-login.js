/* ========================================= */
/* --- SCRIPT SCANNER QR CODE WIIFI --- */
/* ========================================= */

var html5QrcodeScanner = null;

function startScan() {
    // Tampilkan area kamera & tombol tutup
    $('#reader').show();
    $('#stop-scan').show();
    
    // Inisialisasi Scanner
    html5QrcodeScanner = new Html5Qrcode("reader");

    // Konfigurasi Scan (FPS & Ukuran Box)
    const config = { fps: 10, qrbox: { width: 200, height: 200 } };
    
    // Mulai Kamera Belakang (environment)
    html5QrcodeScanner.start({ facingMode: "environment" }, config, onScanSuccess).catch(err => {
        alert("Gagal membuka kamera: " + err + "\n\nPastikan Anda menggunakan HTTPS atau browser mengizinkan akses kamera.");
        $('#reader').hide();
        $('#stop-scan').hide();
    });
}

function onScanSuccess(decodedText, decodedResult) {
    // 1. Masukkan hasil scan ke kolom username & password
    var inputUser = document.getElementById('user-voucher');
    var inputPass = document.getElementById('pass-voucher');
    
    if(inputUser && inputPass) {
        inputUser.value = decodedText;
        inputPass.value = decodedText;
        
        // 2. Matikan kamera agar hemat baterai
        stopScan();

        // 3. AUTO SUBMIT (Langsung Login)
        // Pastikan form memiliki method submit yang valid
        if(inputUser.form) {
            inputUser.form.submit();
        }
    } else {
        alert("Error: Kolom input voucher tidak ditemukan.");
    }
}

function stopScan() {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.stop().then((ignore) => {
            // Kamera berhenti, sembunyikan elemen
            $('#reader').hide();
            $('#stop-scan').hide();
        }).catch((err) => {
            console.log("Stop failed: ", err);
        });
    }
}