/* --- FITUR KEAMANAN --- */

// 1. Mencegah Seleksi Teks (Backup untuk CSS)
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// 2. Blokir Klik Kanan
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    alert("Klik kanan dinonaktifkan demi keamanan.");
});

// 3. Blokir Tombol Keyboard
document.onkeydown = function(e) {
    // Mencegah F12
    if (e.keyCode == 123) {
        e.preventDefault();
        alert("Akses Developer Tools (F12) diblokir.");
        return false;
    }

    // Mencegah kombinasi Ctrl+Shift+... (I, C, J)
    if (e.ctrlKey && e.shiftKey) {
        var key = e.key.toLowerCase();
        if (key === 'i' || key === 'c' || key === 'j') {
            e.preventDefault();
            alert("Akses Inspeksi Elemen diblokir.");
            return false;
        }
    }

    // Mencegah Ctrl+U (View Source)
    if (e.ctrlKey && (e.key.toLowerCase() === 'u')) {
        e.preventDefault();
        alert("Melihat kode sumber (View Source) diblokir.");
        return false;
    }

    // Mencegah Ctrl+A (Select All)
    if (e.ctrlKey && (e.key.toLowerCase() === 'a')) {
        e.preventDefault();
        alert("Fitur Select All (Ctrl+A) dinonaktifkan.");
        return false;
    }

    // Mencegah Ctrl+S (Save Page)
    if (e.ctrlKey && (e.key.toLowerCase() === 's')) {
        e.preventDefault();
        alert("Menyimpan halaman ini tidak diperbolehkan.");
        return false;
    }
};